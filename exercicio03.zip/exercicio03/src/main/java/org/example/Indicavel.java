package org.example;

public interface Indicavel {
    Boolean isElegivel();
    Short getNumeroIndicacoes();
    void setElegivel(Boolean elegivel);
    void setNumeroIndicacoes(Short numeroIndicacoes);
}
